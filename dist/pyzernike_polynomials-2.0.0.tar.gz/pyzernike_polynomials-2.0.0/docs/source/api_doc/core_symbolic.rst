pyzernike.core_symbolic
===========================

.. autofunction:: pyzernike.core_symbolic