pyzernike.core_polynomial
===========================

.. autofunction:: pyzernike.core_polynomial