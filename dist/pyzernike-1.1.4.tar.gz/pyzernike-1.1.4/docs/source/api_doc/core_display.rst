pyzernike.core_display
===========================

.. autofunction:: pyzernike.core_display